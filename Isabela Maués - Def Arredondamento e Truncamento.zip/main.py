import math
#maquina de 3 digitos (entre -4 e 4)
#DEF

#resolver por arredondamento ou truncamento.
#arredondamento: 0.23586 10³ -> 0.236 10³
#truncamento: 0.23586 10³ -> 0.235 10³


# entrar com x = 0.23586 -> 0.236
x = float(input("Entre com o valor de x:"))

#intervalo de -dig a dig
#dig = int(input("Entre com o numero de digitos da maquina:"))
#print(-dig)


def num_after_point(x):
    s = str(x)
    if not '.' in s:
        return 0
    return len(s) - s.index('.') - 1

def arredondamento (x):
    #print ((round(0.23586 * 10**3))/(10**3))
    base = 10**3
    arredondado = (round(x*base)/base)
    return (arredondado)

def truncamento (x,digits):
   
   trunc = [];
   
   trunc = str(x).split('.')
   print(trunc)
   trunc1 = trunc[0]
   trunc2 =trunc[1]
   trunc = '.'.join([trunc1, trunc2[:3]])
   return trunc


print("numero de casas depois da vírgula: ",num_after_point(x),"\n")
print ("arredondamento: ",arredondamento(x),"\n")
print("truncamento: ",truncamento (x,3),"\n")
